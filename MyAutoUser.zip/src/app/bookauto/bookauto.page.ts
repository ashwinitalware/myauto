import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookauto',
  templateUrl: './bookauto.page.html',
  styleUrls: ['./bookauto.page.scss'],
})
export class BookautoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
