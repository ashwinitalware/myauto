import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-destination',
  templateUrl: './destination.page.html',
  styleUrls: ['./destination.page.scss'],
})
export class DestinationPage implements OnInit {



  constructor(

  ) { }

  ngOnInit() {
  }

  //   function show(value) {
  //   document.querySelector(".text-box").value = value;
  // }

  // let dropdown = document.querySelector(".dropdown")
  // dropdown.onclick = function () {
  //   dropdown.classList.toggle("active")
  // }

}
