import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editpage',
  templateUrl: './editpage.page.html',
  styleUrls: ['./editpage.page.scss'],
})
export class EditpagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
