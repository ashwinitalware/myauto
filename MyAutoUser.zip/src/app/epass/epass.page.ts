import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-epass',
  templateUrl: './epass.page.html',
  styleUrls: ['./epass.page.scss'],
})
export class EpassPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
