import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerfeedback',
  templateUrl: './customerfeedback.page.html',
  styleUrls: ['./customerfeedback.page.scss'],
})
export class CustomerfeedbackPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
